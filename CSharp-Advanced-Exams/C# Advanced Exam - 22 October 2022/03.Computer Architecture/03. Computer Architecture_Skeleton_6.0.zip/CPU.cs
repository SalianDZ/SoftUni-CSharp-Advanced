﻿namespace ComputerArchitecture
{
    public class CPU
    {
    }
}
