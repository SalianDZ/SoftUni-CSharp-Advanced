﻿namespace ComputerArchitecture
{
    public class Computer
    {
    }
}
